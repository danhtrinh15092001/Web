<?php
    class Constants{
        public static $firstNameCharactters="First name must be between 2 and 25 characters!";
        public static $lastNameCharactters="Last name must be between 2 and 25 characters!";
        public static $emailTaken="Email is already exist";
        public static $emailInvalid="Email is Invalid";
        public static $diffentpass="Password does not match";
        public static $shortpass="Password is short";
        public static $NotAlphapass="Passwords can only be numbers and letters";
    }
?>